#PDF Catalog Plugin
This plugin finds all PDF files in your Wordpress media library and create a catalog with Title, Download/Read buttons, and Thumbnails.

#Install
Upload "PDF Catalog.zip"
Activate Plugin
Add shortcode [mypdf_catalog] on any page or post